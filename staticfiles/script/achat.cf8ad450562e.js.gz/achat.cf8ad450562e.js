// Achats - remplir le select fournisseur simplement
(function($){
  const DEBUG = true; function dbg(...a){ if(DEBUG) try{ console.log('[Achat]', ...a);}catch(e){} }
  const API_FOURNISSEURS = '/API/fournisseurs/';
  const API_PRODUITS = '/API/produits/';
  const API_ENTREPOTS = '/API/entrepots/';

  let achatsDataTable = null;

  function asList(data){
    if(Array.isArray(data)) return data;
    if(data && Array.isArray(data.results)) return data.results;
    if(data && typeof data === 'object') return Object.values(data);
    return [];
  }

  // CSRF helpers
  function getCookie(name){
    var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? decodeURIComponent(match[2]) : null;
  }
  function getCSRFToken(){
    return getCookie('csrftoken') || (document.querySelector('input[name="csrfmiddlewaretoken"]') && document.querySelector('input[name="csrfmiddlewaretoken"]').value) || '';
  }

  function loadFournisseurs(){
    const $sel = $('#fournisseur');
    if(!$sel.length){ dbg('loadFournisseurs: #fournisseur not found, skip'); return; }
    // garder la première option
    const first = $sel.find('option').first().clone();
    $sel.empty().append(first);

    $.ajax({ url: API_FOURNISSEURS + '?page_size=1000', method: 'GET', dataType: 'json' })
      .done(function(data){
        const list = asList(data);
        dbg('loadFournisseurs: size =', list.length, list);
        let defaultId = null;
        list.forEach(function(f){
          // Fournisseur utilise 'libelle' au lieu de nom/prenom
          const label = f.libelle || ('Fournisseur #' + f.id);
          const $opt = $('<option>').val(f.id).text(label).appendTo($sel);
          // detect a "Divers" fournisseur by name
          const nameLc = (label || '').toLowerCase();
          if(defaultId === null && (nameLc === 'divers' || nameLc === 'fournisseur divers' || nameLc.includes('divers'))){
            defaultId = f.id;
          }
        });
        if(defaultId !== null){ $sel.val(defaultId); }
      })
      .fail(function(xhr){
        dbg('loadFournisseurs: fail', xhr.status, xhr.responseText || xhr.statusText);
      });
  }

  function loadProduits(query){
    const $sel = $('#sproduit');
    if(!$sel.length){ dbg('loadProduits: #sproduit not found, skip'); return; }
    const first = $sel.find('option').first().clone();
    $sel.empty().append(first);

    let url = API_PRODUITS + '?page_size=1000';
    if(query && query.trim()){
      url = API_PRODUITS + 'search/?q=' + encodeURIComponent(query.trim());
    }

    $.ajax({ url: url, method: 'GET', dataType: 'json' })
      .done(function(data){
        const list = asList(data);
        dbg('loadProduits: size =', list.length, list);
        list.forEach(function(p){
          const label = (p.reference ? (p.reference + ' - ') : '') + (p.designation || 'Produit #' + p.id);
          $('<option>').val(p.id).text(label).appendTo($sel);
        });
        // si un seul résultat, sélectionner automatiquement
        if(list.length === 1){ $sel.val(list[0].id); }
      })
      .fail(function(xhr){ dbg('loadProduits: fail', xhr.status, xhr.responseText || xhr.statusText); });
  }

  function loadWarehouses(){
    const $sel = $('#warehouse');
    if(!$sel.length){ dbg('loadWarehouses: #warehouse not found, skip'); return; }
    const first = $sel.find('option').first().clone();
    $sel.empty().append(first);

    $.ajax({ url: API_ENTREPOTS, method: 'GET', dataType: 'json' })
      .done(function(data){
        const list = asList(data).filter(function(w){ return w.is_active !== false; });
        dbg('loadWarehouses: size =', list.length, list);
        let defaultId = null;
        list.forEach(function(w){
          const label = (w.code ? (w.code + ' - ') : '') + (w.name || ('Entrepôt #' + w.id));
          const $opt = $('<option>').val(w.id).text(label).appendTo($sel);
          if(defaultId === null) defaultId = w.id;
        });
        if(defaultId !== null){ $sel.val(defaultId); }
      })
      .fail(function(xhr){ dbg('loadWarehouses: fail', xhr.status, xhr.responseText || xhr.statusText); });
  }

  function bindProduitFilters(){
    const $ref = $('#ref');
    const $code = $('#codebar');
    const $sel = $('#sproduit');
    if(!$sel.length) return;

    // initial load
    loadProduits();

    function doSearch(){
      const q = ($ref.val()||'').toString().trim() || ($code.val()||'').toString().trim();
      loadProduits(q);
    }

    let t; function debounced(){ clearTimeout(t); t = setTimeout(doSearch, 300); }
    $ref.on('input', debounced);
    $code.on('input', debounced);
  }

  function normalizeNumberToFloat(str){
    if(str == null) return NaN; let s = (''+str).trim(); if(!s) return NaN; s = s.replace(/\s+/g,'');
    if(s.includes(',') && s.includes('.')){ s = s.replace(/\./g,''); s = s.replace(',', '.'); }
    else if(s.includes(',')){ s = s.replace(',', '.'); }
    s = s.replace(/[^0-9\.-]/g,''); const v = parseFloat(s); return isNaN(v) ? NaN : v;
  }

  function buildAchatPayload(){
    const uniteAchat = ($('#unite_achat').val()||'piece').toString();

    // En mode carton, prix_achat contient le prix unitaire calculé
    // En mode pièce, prix_achat contient le prix unitaire saisi
    const prixStr = ($('#prix_achat').val()||'').toString();
    const prix = normalizeNumberToFloat(prixStr);

    // Calculer la quantité totale en pièces
    let quantiteTotale = 0;
    if(uniteAchat === 'carton'){
      const qteCarton = parseInt(($('#qte_carton').val()||'0').toString(), 10);
      const piecesParCarton = parseInt(($('#pieces_par_carton').val()||'1').toString(), 10);
      quantiteTotale = qteCarton * piecesParCarton;
    } else {
      quantiteTotale = parseInt(($('#quantite').val()||'0').toString(), 10);
    }

    const data = {
      date_Achat: ($('#datea').val()||'').toString().slice(0,10),
      date_expiration: ($('#dateexp').val()||'').toString().slice(0,10) || null,
      unite_achat: uniteAchat,
      quantite: quantiteTotale,
      pieces_par_carton: parseInt(($('#pieces_par_carton').val()||'1').toString(), 10),
      prix_achat: isNaN(prix) ? 0 : prix,
      fournisseur: parseInt(($('#fournisseur').val()||'0').toString(), 10) || null,
      produit: parseInt(($('#sproduit').val()||'0').toString(), 10) || null,
      warehouse: parseInt(($('#warehouse').val()||'0').toString(), 10) || null
    };
    if(!data.fournisseur) delete data.fournisseur;
    if(!data.produit) delete data.produit;
    if(!data.warehouse) delete data.warehouse;
    if(!data.date_expiration) data.date_expiration = null; // explicit null
    return data;
  }

  function createAchat(){
    const payload = buildAchatPayload();
    if(!payload.produit){ alert('Veuillez sélectionner un produit'); return; }
    if(!payload.fournisseur){ alert('Veuillez sélectionner un fournisseur'); return; }
    if(!payload.quantite || payload.quantite <= 0){ alert('Quantité invalide'); return; }
    return $.ajax({ url:'/API/achats/', method:'POST', contentType:'application/json', headers:{ 'X-CSRFToken': getCSRFToken() }, data: JSON.stringify(payload) })
      .done(function(){
        alert('Achat ajouté');
        // refresh table
        loadAchats();
        // reset quantity fields (keep date and selections)
        $('#quantite').val('');
        $('#qte_carton').val('0');
        $('#prix_achat').val('');
        $('#prix_carton').val('');
        $('#total_achat').val('');
        $('#ref').val('');
        $('#codebar').val('');
      })
      .fail(function(xhr){ alert((xhr.responseJSON && (xhr.responseJSON.detail||xhr.responseJSON.error)) || 'Erreur ajout achat'); });
  }

  function fetchAchat(id){
    return $.ajax({ url: '/API/achats/' + id + '/', method: 'GET', dataType: 'json' });
  }

  function updateAchat(id){
    const payload = buildAchatPayload();
    if(!payload.quantite || payload.quantite <= 0){ alert('Quantité invalide'); return; }
    return $.ajax({ url:'/API/achats/' + id + '/', method:'PUT', contentType:'application/json', headers:{ 'X-CSRFToken': getCSRFToken() }, data: JSON.stringify(payload) })
      .done(function(){
        alert('Achat mis à jour');
        loadAchats();
        resetEditMode();
      })
      .fail(function(xhr){ alert((xhr.responseJSON && (xhr.responseJSON.detail||xhr.responseJSON.error)) || 'Erreur mise à jour achat'); });
  }

  function deleteAchat(id){
    if(!confirm('Confirmer la suppression de cet achat ?')) return;
    return $.ajax({ url:'/API/achats/' + id + '/', method:'DELETE', headers:{ 'X-CSRFToken': getCSRFToken() } })
      .done(function(){
        loadAchats();
      })
      .fail(function(xhr){ alert((xhr.responseJSON && (xhr.responseJSON.detail||xhr.responseJSON.error)) || 'Erreur suppression achat'); });
  }

  function enterEditMode(achat){
    try {
      if(achat.date_Achat) $('#datea').val((achat.date_Achat||'').toString().slice(0,10));
      if(achat.date_expiration) $('#dateexp').val((achat.date_expiration||'').toString().slice(0,10)); else $('#dateexp').val('');

      // Gérer unite_achat et champs liés
      const uniteAchat = achat.unite_achat || 'piece';
      $('#unite_achat').val(uniteAchat);

      if(uniteAchat === 'carton'){
        // Mode carton: calculer qte_carton à partir de la quantité totale
        const piecesParCarton = achat.pieces_par_carton || 1;
        const qteCarton = Math.floor(achat.quantite / piecesParCarton);
        $('#qte_carton').val(qteCarton);
        $('#pieces_par_carton').val(piecesParCarton);
        // Calculer le prix par carton à partir du prix unitaire
        const prixCarton = (achat.prix_achat || 0) * piecesParCarton;
        $('#prix_carton').val(prixCarton.toFixed(2));
      } else {
        // Mode pièce
        $('#quantite').val(achat.quantite);
        $('#prix_achat').val(achat.prix_achat);
      }

      if(achat.fournisseur) $('#fournisseur').val(achat.fournisseur);
      if(achat.produit) $('#sproduit').val(achat.produit);
      if(achat.warehouse) $('#warehouse').val(achat.warehouse);

      // Trigger toggle to show/hide appropriate fields
      if(typeof toggleAchatParCarton === 'function') toggleAchatParCarton();
      // Recalculate totals
      if(typeof calculateAchatTotal === 'function') calculateAchatTotal();
    } catch(e) { dbg('enterEditMode error:', e); }
    $('#id').val(achat.id);
    $('#section-achat #btn').text('Mettre à jour').attr('data-mode','edit');
  }

  function resetEditMode(){
    $('#id').val('');
    $('#section-achat #btn').text('Ajouter').attr('data-mode','add');
    // Reset carton mode fields
    $('#unite_achat').val('piece');
    $('#qte_carton').val('0');
    $('#pieces_par_carton').val('1');
    $('#prix_carton').val('');
    // Trigger toggle to reset field visibility
    if(typeof toggleAchatParCarton === 'function') toggleAchatParCarton();
  }

  function renderAchats(list){
    const $table = $('#tachat');
    const $tbody = $table.find('tbody#table-content');
    if(!$tbody.length) return;

    // Détruire l'instance DataTable existante
    if(achatsDataTable){
      try {
        achatsDataTable.destroy();
        achatsDataTable = null;
      } catch(e) { dbg('DataTable destroy error:', e); }
    }

    $tbody.empty();
    if(!list || !list.length){
      $tbody.append('<tr><td colspan="12" class="text-center text-muted">Aucun achat</td></tr>');
      return;
    }
    list.forEach(function(a){
      const tr = $('<tr>');
      const sym = a.currency_symbol || 'DA';

      // ID
      tr.append('<td>'+(a.id||'')+'</td>');

      // Date
      tr.append('<td>'+(a.date_Achat||'')+'</td>');

      // Unité d'achat (Pièce ou Carton)
      const uniteDisplay = a.unite_achat_display || (a.unite_achat === 'carton' ? 'Carton' : 'Pièce');
      tr.append('<td>'+uniteDisplay+'</td>');

      // Quantité (cartons ou pièces selon le mode)
      let qteDisplay = '';
      if(a.unite_achat === 'carton'){
        // Afficher le nombre de cartons
        const nbCartons = a.pieces_par_carton > 0 ? Math.floor(a.quantite / a.pieces_par_carton) : 0;
        qteDisplay = nbCartons + ' carton' + (nbCartons > 1 ? 's' : '');
      } else {
        qteDisplay = (a.quantite||0) + ' pcs';
      }
      tr.append('<td>'+qteDisplay+'</td>');

      // Pièces par carton
      const pcsParCarton = a.unite_achat === 'carton' ? (a.pieces_par_carton||1) : '-';
      tr.append('<td>'+pcsParCarton+'</td>');

      // Quantité totale en pièces
      const qteTotalePcs = a.quantite_pieces || a.quantite || 0;
      tr.append('<td>'+qteTotalePcs+' pcs</td>');

      // Fournisseur
      var fournisseurTxt = (a.fournisseur_nom||'') + (a.fournisseur_prenom?(' '+a.fournisseur_prenom):'');
      // Pour les fournisseurs, utiliser libelle s'il est disponible (car Fournisseur n'a pas nom/prenom mais libelle)
      if(!fournisseurTxt && a.fournisseur_libelle) fournisseurTxt = a.fournisseur_libelle;
      tr.append('<td>'+ (fournisseurTxt || a.fournisseur || '') +'</td>');

      // Produit
      var prodTxt = (a.produit_reference? (a.produit_reference+' - ') : '') + (a.produit_designation||'');
      tr.append('<td>'+ (prodTxt || a.produit || '') +'</td>');

      // Prix unitaire (par pièce)
      var prixUnitaire = a.prix_unitaire_piece || a.prix_achat || 0;
      tr.append('<td>'+prixUnitaire.toFixed(2)+' '+sym+'</td>');

      // Total
      var total = (a.total_achat != null) ? a.total_achat : 0;
      tr.append('<td>'+total.toFixed(2)+' '+sym+'</td>');

      // Actions
      tr.append('<td><button class="btn btn-sm btn-outline-danger" data-action="delete" data-id="'+a.id+'">Supprimer</button></td>');
      tr.append('<td><button class="btn btn-sm btn-outline-primary" data-action="edit" data-id="'+a.id+'">Modifier</button></td>');
      $tbody.append(tr);
    });

    // Initialiser DataTables
    try {
      if($.fn.DataTable && list && list.length > 0){
        achatsDataTable = $table.DataTable({
          destroy: true,
          language: {
            url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/fr-FR.json',
            emptyTable: 'Aucun achat'
          },
          order: [[0, 'desc']], // Trier par ID décroissant
          columnDefs: [
            { targets: [10, 11], orderable: false }, // Boutons non triables
            { targets: [8, 9], className: 'text-right' } // Prix alignés à droite
          ],
          pageLength: 25,
          dom: 'Bfrtip',
          buttons: []
        });
      }
    } catch(e) {
      dbg('DataTable init error:', e);
    }
  }

  function loadAchats(){
    const url = '/API/achats/?page_size=1000';
    return $.ajax({ url:url, method:'GET', dataType:'json' })
      .done(function(data){ const list = Array.isArray(data)?data:(data.results||data||[]); renderAchats(list); })
      .fail(function(xhr){ console.warn('loadAchats failed', xhr.status, xhr.responseText||xhr.statusText); });
  }

  function updateTotalAchat(){
    const qty = parseInt(($('#quantite').val()||'0').toString(), 10) || 0;
    const p = normalizeNumberToFloat($('#prix_achat').val()||'0');
    const total = (isNaN(p)?0:p) * qty;
    $('#total_achat').val(total.toFixed(2));
  }

  function init(){
    if(!document.getElementById('tachat')){ dbg('init: achats page not detected, skip'); return; }
    // Set default date to today's system date if empty
    var $date = $('#datea');
    if($date.length && (!$date.val() || $date.val()==='')){
      try {
        var tzOffset = (new Date()).getTimezoneOffset() * 60000;
        var localISODate = (new Date(Date.now() - tzOffset)).toISOString().slice(0,10);
        $date.val(localISODate);
      } catch(e) { try{ $date.val(new Date().toISOString().slice(0,10)); }catch(_){} }
    }
    // bind add/update button
    $(document).off('click', '#section-achat #btn').on('click', '#section-achat #btn', function(){
      var mode = $(this).attr('data-mode') || 'add';
      var id = $('#id').val();
      if(mode === 'edit' && id){ updateAchat(id); } else { createAchat(); }
    });
    // bind table actions (edit/delete)
    $(document).off('click', '#tachat [data-action="delete"]').on('click', '#tachat [data-action="delete"]', function(){
      var id = $(this).data('id');
      deleteAchat(id);
    });
    $(document).off('click', '#tachat [data-action="edit"]').on('click', '#tachat [data-action="edit"]', function(){
      var id = $(this).data('id');
      fetchAchat(id).done(function(data){ enterEditMode(data); });
    });
    // reactive total calc
    $(document).off('input', '#quantite, #prix_achat').on('input', '#quantite, #prix_achat', updateTotalAchat);
    loadFournisseurs();
    loadWarehouses();
    bindProduitFilters();
    loadAchats();
  }

  $(document).ready(init);
  document.addEventListener('fragment:loaded', function(e){ if(e && e.detail && e.detail.name==='achat'){ init(); } });
})(jQuery);
